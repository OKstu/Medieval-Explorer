﻿using static System.Console;


namespace Adventure
{
    internal class Program
    {

        public static void Main(string[] args)
        {
            TitleArt.DrawDiagram();
            WriteLine("Press Enter to begin.");
            Player New = new Player();
            Clear();
            New.DisplayNewPlayerInfo();
            Clear();
            Menu1.MainMenu();
            MainGame.GamePlay();


            ReadKey();

        }
    }
}
