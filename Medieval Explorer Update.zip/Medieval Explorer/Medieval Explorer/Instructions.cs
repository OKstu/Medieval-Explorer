﻿using System;
using static System.Console;

namespace Adventure
{
    class Instructions
    {
        public static void ShowInstructions()
        {
            WriteLine("Nothing much to do. Just pick a choice to make. The rest will be explain when you begin the game.");
        }
    }
}