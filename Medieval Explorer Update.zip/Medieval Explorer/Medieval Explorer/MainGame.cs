﻿using System;
using System.Collections;
using System.IO;
using static System.Console;

namespace Adventure
{
    public class MainGame
    {
        public static void Run()
        {
            WriteLine("This is just a simple demo of senarioes. Every level eill have at least 3 of them, with the posibillity of having more choices added to the game depending on your choices. Make sure you pick one carefully. You only have one level for this demo. Hope you enjoy");
        }

        public static void NewGame()
        {
            ForegroundColor = ConsoleColor.White;
            WriteLine("Level 1");
            WriteLine("-------------------------------------------------------------------------------------------------------");
            LevelActivation.LoadLevel1();
            WriteLine("--------------------------------------------------------------------------------------------------------");
            WriteLine("Objective: Nothing much to do. Just try to keep yourself alive while checking out the city");
            WriteLine("Press any key to begin.");
            ReadKey();
            Clear();
        }

        public static void GamePlay()
        {
            WriteLine("You have enter the city of Enzurah");
            WriteLine();
            WriteLine("There's a man passing maps to people entering the city. What do you do afterwards?");
            WriteLine("-------------------------------------------------------------------------------------------------------");
            WriteLine("1. Take one of the maps he hands to you (this is the only option. More wil be available soon)");
            GameChoice1();
        }

        static void GameChoice1()
        {
            string Choice1 = ReadLine();

            if (Choice1 == "1")
            {
                WriteLine("You take the map and start reading it.");
                ReadKey();
                WriteLine();
                WriteLine("You've notice that there are many places to be present in. Incidently, due to development hell, you only have 2 choices. Which 1 of the 2 huge places will you travel to?");
                WriteLine("-------------------------------------------------------------------------------------------------------");
                WriteLine("1. The Neighborhood of Warriors");
                WriteLine("2. Crimson Center");
                GameChoice2O1();
            }

            void GameChoice2O1()
            {
                string Choice201 = ReadLine();

                if (Choice201 == "1")
                {
                    WriteLine("You decided to go to the Neighborhood of Warriors.");
                    ReadKey();
                    Clear();
                    WriteLine("The Neighborhood of Warriors.");
                    WriteLine("This the place were current and retire warriors live in. It serves as an excellent recreational center and a great place for tourists to visit");
                    WriteLine("-------------------------------------------------------------------------------------------------------");
                    WriteLine("After you enter the neighborhood, you are greated by one of the tourist guide. His name is Geardnex Honolson. He's a retired warrior and he wants to introduce you yo the place. What do yo do?");
                    WriteLine("-------------------------------------------------------------------------------------------------------");
                    WriteLine("1. Follow Him");
                    WriteLine("2. Tell him no");

                    string QC3 = ReadLine();

                    if (QC3 == "1")
                    {
                        WriteLine("You decided to follow him.");
                        ReadKey();
                        WriteLine("Here's a summary of all the places you went to.");
                        ReadKey();
                        WriteLine("-------------------------------------------------------------------------------------------------------");
                        WriteLine("The administration center is the first place to go there when registering for a free home, submitting requestes for changes, or applying for programs (Memberships are for current or retire warriors only, but there are fre guest memberships available for non-warriors).");
                        WriteLine("The main hall is where members hang out, talk, and have a feast.");
                        WriteLine("The recreational center is a place where members do, well, recreational stuff (art, sports, reading, etc).");
                        WriteLine("The dorms are homes for the members that are personalized to fit the needs (and wants) of each.");
                        WriteLine("Finally, the supply center is the place where members and staff recieve their stuff (mail, devices, etc).");
                        ReadKey();
                        WriteLine("-------------------------------------------------------------------------------------------------------");
                        WriteLine("The tour is finish. What will you do now?");
                        WriteLine("-------------------------------------------------------------------------------------------------------");
                        WriteLine("1. Crimson Center");
                        string QCI1 = ReadLine();

                        if (QCI1 == "1")
                        {
                            WriteLine("You decided to go to the Crimson Center.");
                            ReadKey();
                            Clear();
                            WriteLine("Crimson Center.");
                            WriteLine("This is the center of thr city, but it is fill with histories of war. The blood on toe ground somehow never changes color or disappears due to the place's unknown properties, hence the name. barely anyone steps into that location without a group of warriors, but in some twisted way, it is to much a spectacle to skip.");
                            WriteLine("-------------------------------------------------------------------------------------------------------");
                            WriteLine("After you enter the center, 3 people approach you. Thet are bloodthirsty fighters who enjoy war. What do yo do?");
                            WriteLine("-------------------------------------------------------------------------------------------------------");
                            WriteLine("1. Fight");
                            WriteLine("2. Negotiate");
                            WriteLine("3. Run");

                            string QC1 = ReadLine();

                            if (QC1 == "1")
                            {
                                WriteLine("You chose to fight");
                                WriteLine("You have managed to defeat them and recieved 10 EXP (Experience Point)");
                                ReadKey();
                                WriteLine();
                                WriteLine("You continue on exploring the center until you see the graves of warriors and casualties on the streets. What do you do now?");
                                WriteLine("-------------------------------------------------------------------------------------------------------");
                                WriteLine("1. Pay your respects");
                                WriteLine("2. Run from the location");
                                WriteLine("3. Kick the grave");
                                string QC102 = ReadLine();
                                
                                if (QC102 == "1")
                                {
                                    WriteLine("You chose to pay them your respects, even though you don't even know those folks.");
                                    WriteLine("-------------------------------------------------------------------------------------------------------");
                                    WriteLine("What now?");
                                    WriteLine("-------------------------------------------------------------------------------------------------------");
                                    WriteLine("Just enter 1 to keep moving (This is where the demo ends. I give all of you player an apology");
                                    string End = ReadLine();

                                    if (End == "1")
                                    {
                                        Clear();
                                        Ending.ThankYou();

                                    }
                                }

                                else if (QC102 == "2")
                                {
                                    WriteLine("You've not only ran from the streets in fear, but you also ran from the Center, even after you defeated the bloodthirsty fighters. Coward!!!");
                                    ReadLine();
                                    WriteLine();
                                    WriteLine("Well, that's it");
                                    ReadKey();
                                    Clear();
                                    Ending.ThankYou();

                                }

                                else if (QC102 == "3")
                                {
                                    WriteLine("You kicked the tomb stones and somehow revive the dead, except they're zombies. You are now treated as a meal. You'll be a zombie later on....... t What the F***!?!?!?!");
                                    WriteLine("Game Over");
                                    Write("Restart (Y to restart or N to return to the menu)? ");
                                    string QC1022 = ReadLine();

                                    if (QC1022 == "y" || QC1022 == "Y")
                                    {
                                        Clear();
                                        MainGame.NewGame();
                                        Clear();
                                        MainGame.GamePlay();
                                    }

                                    else if (QC1022 == "n" || QC1022 == "N")
                                    {
                                        Menu1.MainMenu();
                                    }
                                }


                            }

                        }
                    }

                    else if (Choice201 == "2")
                    {

                        WriteLine("You decided to go to the Crimson Center.");
                        ReadKey();
                        Clear();
                        WriteLine("Crimson Center.");
                        WriteLine("This is the center of thr city, but it is fill with histories of war. The blood on toe ground somehow never changes color or disappears due to the place's unknown properties, hence the name. barely anyone steps into that location without a group of warriors, but in some twisted way, it is to much a spectacle to skip.");
                        WriteLine("-------------------------------------------------------------------------------------------------------");
                        WriteLine("After you enter the center, 3 people approach you. Thet are bloodthirsty fighters who enjoy war. What do yo do?");
                        WriteLine("-------------------------------------------------------------------------------------------------------");
                        WriteLine("1. Fight");
                        WriteLine("2. Negotiate");

                        string QC1 = ReadLine();

                        if (QC1 == "1")
                        {
                            WriteLine("You chose to fight");
                            WriteLine("You have managed to defeat them and recieved 10 EXP (Experience Point)");
                            ReadKey();
                            WriteLine();
                            WriteLine("You continue on exploring the center until you see the graves of warriors and casualties on the streets. What do you do now?");
                            WriteLine("-------------------------------------------------------------------------------------------------------");
                            WriteLine("1. Pay your respects");
                            WriteLine("2. Run from the location");
                            WriteLine("3. Kick the grave");
                            string QC102 = ReadLine();
                            if (QC102 == "1")
                            {
                                WriteLine("You chose to pay them your respects, even though you don't even know those folks.");
                            }

                            else if (QC102 == "2")
                            {
                                WriteLine("You've not only ran from the streets in fear, but you also ran from the Center, even after you defeated the bloodthirsty fighters. Coward!!!");
                                ReadLine();
                                Clear();
                                WriteLine("Where do you head to next?");
                                WriteLine("-------------------------------------------------------------------------------------------------------");
                                WriteLine("1. The Neighborhood of Warriors");

                                string QC1023 = ReadLine();

                                if (QC1023 == "1")
                                {
                                    WriteLine("You decided to go to the Neighborhood of Warriors.");
                                    ReadKey();
                                    Clear();
                                    WriteLine("The Neighborhood of Warriors.");
                                    WriteLine("This the place were current and retire warriors live in. It serves as an excellent recreational center and a great place for tourists to visit");
                                    WriteLine("-------------------------------------------------------------------------------------------------------");
                                    WriteLine("After you enter the neighborhood, you are greated by one of the tourist guide. His name is Geardnex Honolson. He's a retired warrior and he wants to introduce you yo the place. What do yo do?");
                                    WriteLine("-------------------------------------------------------------------------------------------------------");
                                    WriteLine("1. Follow Him");
                                    WriteLine("2. Tell him no");
                                    string QCI3 = ReadLine();

                                    if (QCI3 == "1")
                                    {
                                        WriteLine("You decided to follow him.");
                                        ReadKey();
                                        WriteLine("Here's a summary of all the places you went to.");
                                        ReadKey();
                                        WriteLine("-------------------------------------------------------------------------------------------------------");
                                        WriteLine("The administration center is the first place to go there when registering for a free home, submitting requestes for changes, or applying for programs (Memberships are for current or retire warriors only, but there are fre guest memberships available for non-warriors).");
                                        WriteLine("The main hall is where members hang out, talk, and have a feast.");
                                        WriteLine("The recreational center is a place where members do, well, recreational stuff (art, sports, reading, etc).");
                                        WriteLine("The dorms are homes for the members that are personalized to fit the needs (and wants) of each.");
                                        WriteLine("Finally, the supply center is the place where members and staff recieve their stuff (mail, devices, etc).");
                                        ReadKey();
                                        WriteLine("-------------------------------------------------------------------------------------------------------");
                                        WriteLine("The tour is finish. That's literally it for the demo");
                                        WriteLine("-------------------------------------------------------------------------------------------------------");
                                        ReadKey();
                                        Clear();
                                        Ending.ThankYou();

                                    }

                                    else if (QCI3 == "2")
                                    {
                                        WriteLine("You can't explore the place without the tourist guide. Now what do you do?");
                                        WriteLine("1. Just Follow Him!!!");
                                        string QCGI3 = ReadLine();

                                        if (QCGI3 == "1")
                                        {
                                            WriteLine("You decided to follow him.");
                                            ReadKey();
                                            WriteLine("Here's a summary of all the places you went to.");
                                            ReadKey();
                                            WriteLine("-------------------------------------------------------------------------------------------------------");
                                            WriteLine("The administration center is the first place to go there when registering for a free home, submitting requestes for changes, or applying for programs (Memberships are for current or retire warriors only, but there are fre guest memberships available for non-warriors).");
                                            WriteLine("The main hall is where members hang out, talk, and have a feast.");
                                            WriteLine("The recreational center is a place where members do, well, recreational stuff (art, sports, reading, etc).");
                                            WriteLine("The dorms are homes for the members that are personalized to fit the needs (and wants) of each.");
                                            WriteLine("Finally, the supply center is the place where members and staff recieve their stuff (mail, devices, etc).");
                                            ReadKey();
                                            WriteLine("-------------------------------------------------------------------------------------------------------");
                                            WriteLine("The tour is finish. That's literally it for the demo");
                                            WriteLine("-------------------------------------------------------------------------------------------------------");
                                            ReadKey();
                                            Clear();
                                            Ending.ThankYou();
                                        }
                                }
                            }

                            else if (QC102 == "3")
                            {
                                WriteLine("You kicked the graves and somehow revive the dead, except they're zombies. You are now treated as a meal. You'll be a zombie later on....... t What the F***!?!?!?!");
                                WriteLine("Game Over");
                                Write("Restart (Y to restart or N to return to the menu)? ");
                                string QC1022 = ReadLine();

                                if (QC1022 == "y" || QC1022 == "Y")
                                {
                                    Clear();
                                    MainGame.NewGame();
                                    Clear();
                                    MainGame.GamePlay();
                                }

                                else if (QC1022 == "n" || QC1022 == "N")
                                {
                                    Menu1.MainMenu();
                                }
                            }
                        }

                        else if (QC1 == "2")
                        {
                            WriteLine("You try to reason with them, but they're way to happy to listen. You are now sliced meat");
                            WriteLine("Game Over");
                            Write("Restart (Y to restart or N to return to the menu)? ");
                            string QC101 = ReadLine();

                            if (QC101 == "y" || QC101 == "Y")
                            {
                                Clear();
                                MainGame.NewGame();
                                Clear();
                                MainGame.GamePlay();
                            }

                            else if (QC101 == "n" || QC101 == "N")
                            {
                                Menu1.MainMenu();
                            }
                        }
                    }

                }
               
            }


        }


    }
}

