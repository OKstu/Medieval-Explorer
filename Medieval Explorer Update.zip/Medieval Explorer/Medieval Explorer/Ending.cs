﻿using static System.Console;

namespace Adventure
{
    public class Ending
    {
        public static void ThankYou()
        {
            TitleArt.DrawDiagram();
            WriteLine("Credits");
            WriteLine("-------------------------------------------------------------------------------------------------------");
            WriteLine("Promgrammer and Developer: Oumar keita (that's me)");
            WriteLine("Extra Help: Mr. Michael Hadley");
            WriteLine("This was rather an interesting project. As a matter of fact, it was a hard project to do. I'm still learning how to code in C# and the experience feels dreadful. The game is still incomplete, so i'm hoping that I could return to the game amd make it better while adding more content to it. I want to thank you for playing this game. Press any key to exit.");
            WriteLine();
            WriteLine("Press any to quit the game");
        }
    }
}