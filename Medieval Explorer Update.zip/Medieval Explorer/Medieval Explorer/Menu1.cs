﻿using System;
using static System.Console;
namespace Adventure
{
    public class Menu1
    {
        public static void MainMenu()
        {
            ForegroundColor = ConsoleColor.White;
            TitleArt.DrawDiagram();
            WriteLine("What would you like to do now?");
            WriteLine(" ");
            ForegroundColor = ConsoleColor.Red;
            WriteLine("1. Play the game");
            ForegroundColor = ConsoleColor.Blue;
            WriteLine("2. Check the instructions");
            ForegroundColor = ConsoleColor.Green;
            WriteLine("3. Change your name");
            ForegroundColor = ConsoleColor.Yellow;
            WriteLine("4. Check your Character Info");
            ForegroundColor = ConsoleColor.Magenta;
            WriteLine("5. Leave for now");
            ForegroundColor = ConsoleColor.White;

            string Choice = ReadLine();


            if (Choice == "1")
            {
                ForegroundColor = ConsoleColor.Red;
                WriteLine("Excellent choice. Let the Game begin");
                ReadKey();
                Clear();
                ForegroundColor = ConsoleColor.White;
                TitleArt.DrawDiagram();
                MainGame.Run();
                WriteLine();
                WriteLine("Press Enter or any key to continue");
                ReadKey();
                Clear();
                MainGame.NewGame();
            }

            else if (Choice == "2")
            {
                Clear();
                ForegroundColor = ConsoleColor.White;
                TitleArt.DrawDiagram();
                ForegroundColor = ConsoleColor.Blue;
                Instructions.ShowInstructions();
                WriteLine("Press any key to return to the menu");
                ReadKey();
                Clear();
                MainMenu();

            }

            else if (Choice == "3")
            {
                Clear();
                TitleArt.DrawDiagram();
                ForegroundColor = ConsoleColor.Green;
                WriteLine("You have chosen to change your name. Are you sure you want to do so");
                WriteLine(" ");
                WriteLine("Y (continue) or N (return to menu)");
                string Option = ReadLine();

                if (Option == "y" || Option == "Y")
                {
                    Clear();
                    ForegroundColor = ConsoleColor.White;
                    TitleArt.DrawDiagram();
                    WriteLine("Your old name has been erased. Press any key to continue.");
                    Player New = new Player();
                    Clear();
                    New.DisplayNewPlayerInfo();
                    Clear();
                    Menu1.MainMenu();
                }

                else if (Option == "n" || Option == "N")
                {
                    Clear();
                    ForegroundColor = ConsoleColor.White;
                    Menu1.MainMenu();

                }

                else
                {
                    Clear();
                    ForegroundColor = ConsoleColor.White;
                    TitleArt.DrawDiagram();
                    ForegroundColor = ConsoleColor.Green;
                    WriteLine("WTF?!?!?!!?!?!?!?!?!? You killed the demo! It's okay. This is just a demo. Just close the game and restart it again.");
                    WriteLine(" ");
                    WriteLine("Press any key to exit");

                }
            }

            else if (Choice == "4")
            {
                Clear();
                TitleArt.DrawDiagram();
                ForegroundColor = ConsoleColor.Yellow;
                WriteLine("This option will be available in the full version");
                WriteLine("Press any key to return to the menu");
                ReadKey();
                Clear();
                Menu1.MainMenu();
            }

            else if (Choice == "5")
            {
                ForegroundColor = ConsoleColor.Magenta;
                WriteLine("The game will now close itself. Press any Key to Leave.");
            }

            else
            {
                Clear();
                TitleArt.DrawDiagram();
                WriteLine("That's not the valid input. Please enter one of the following choices.");
                WriteLine("Press any key to return to the menu");
                ReadKey();
                Clear();
                Menu1.MainMenu();

            }
        }
    }

}
