﻿using System;
using System.Collections;
using System.IO;
using System.Data;
using static System.Console;

namespace Adventure
{
    internal class Player
    {
        public string Name;
        public int Score;
        public int EXP;
        public int Level;
        public int ExtraEXP1;

        public Player()
        {
            Name = ReadLine();
            Score = 0;
            EXP = 0;
            Level = 0;
            ExtraEXP1 = 10;


        }
        public void DisplayNewPlayerInfo()
        {
            TitleArt.DrawDiagram();
            WriteLine("What's your name?");
            Write("Name: ");
            Name = ReadLine();

            Clear();
            TitleArt.DrawDiagram();
            WriteLine($"Your Name is {Name}.");
            WriteLine($"Your Current Level of Experience is {EXP}.");
            WriteLine($"Your Current Score is {Score}.");
            WriteLine($"Your Current Level is {Level}.");

            ReadKey();
        }

        public void DisplayOldPlayerInfo()
        {
            Clear();
            TitleArt.DrawDiagram();
            WriteLine($"Your Name is {Name}.");
            WriteLine($"Your Current Level of Experience is {EXP}.");
            WriteLine($"Your Current Score is {Score}.");
            WriteLine($"Your Current Level is {Level}.");
            PointsSystem1();

        }

        public void PointsSystem1()
        {
            Write(EXP + ExtraEXP1);
        }
    }

}   
