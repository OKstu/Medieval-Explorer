﻿using Figgle;
using static System.Console;

namespace Adventure
{
    internal class TitleArt
    {
        public static void DrawDiagram()
        {
            WriteLine(FiggleFonts.Doom.Render("Medieval Explorer (Demo)"));
        }
    }
}
