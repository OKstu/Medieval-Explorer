﻿using System;
using static System.Console;

namespace Adventure
{
    internal static class LevelActivation
    {
        public static void LoadLevel1()
        {
            Location One = new Location();
            One.LoadLevel("Levels/Level1.txt");
            One.DisplayInfo();
        }
    }
}
