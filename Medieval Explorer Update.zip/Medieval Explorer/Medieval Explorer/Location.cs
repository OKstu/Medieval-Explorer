﻿using System.IO;
using static System.Console;
namespace Adventure
{
    public class Location
    {
        public string Level;
        public string Information;
        public string Difficulty;


        public Location()
        {
            Level = "Level";
            Information = "Infomation";
            Difficulty = "Difficulty";
        }



        public void DisplayInfo()
        {
            WriteLine($"LName: {Level}");
            WriteLine($"!nfo: {Information}");
            WriteLine($"Difficulty: {Difficulty}");
        }

        public void LoadLevel(string row)
        {
            string[] section = File.ReadAllLines(row);
            Level = ConnectEachLineToString(section[0]);
            Information = ConnectEachLineToString(section[1]);
            Difficulty = ConnectEachLineToString(section[2]);
        }

        private string ConnectEachLineToString(string section)
        {
            string[] pieces = section.Split(':');
            string value = pieces[0].Trim();
            return value;
        }
    }
}